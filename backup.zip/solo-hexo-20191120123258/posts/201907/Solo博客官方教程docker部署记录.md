title: Solo 博客，官方教程docker 部署记录
date: '2019-07-14 07:08:17'
updated: '2019-07-31 15:13:17'
tags: [记录分享, 随笔]
permalink: /articles/2019/07/14/1563059297117.html
---
# 云服务器
### &emsp;云服务器选购篇
&emsp; 对于服务器什么得在此不多作赘述，百度腾讯阿里国内任选，学生新人有优惠，差不多10元人民币一个月，优点是配置高速度快，国内IP爽歪歪，北京上海等地任选，缺点也有，对于国内域名要强制备案而言，确实麻烦，而且说起来我曾经在备案期间，对于要幕布拍照这个举动（加手持身份证照片等）这类麻烦事情真的是有够郁闷+难受，同专业里的同学差点以为我要裸贷了...... 

<div align="center"> <img style = "width:150px" src="https://img.hacpai.com/file/2019/07/image-33d8f164.png"/></div>
&emsp;

&emsp;如果想要省去国内备案的麻烦步骤，可以考虑国外的云计算运营商，当然麻烦也是有的，首先，对于国外的IP，国内防火墙哪天心情不好就扔进屏蔽列表了也说不定，这是其一把，其二，访问速度会有一定debuff，这个也是不可避免的，我个人用的是美国贼几把便宜的服务商Virmach的机器，512MB内存+1Core酱紫的，15RMB差不多一个月把（没记错的话），早上访问速度不错，晚上贼卡，自己加了个CDN上去总算有所改善把。当然这个以后慢慢讲。





&emsp;所以关于服务器选购我个人没什么好建议可给，各位看官有想要参考此篇内容搭建博客的请自行到百度必应谷歌上搜索便宜又好用的云服务器商，我个人就不在此卖弄了。

### &emsp;服务器系统选择
&emsp; 说到这里，我个人以CentOS 7 为例进行记录说明，当然如果有同学喜欢用Ubuntu的话也没问题，看个人喜好和习惯，只要下面所提到的必要环境能顺利搭建就成。

---

## 正片，搭建记录
&emsp;首先必要的环境有，mysql5.7以上版本, docker, nginx  


### 首先mysql5.7的安装
```
#下载
wget https://dev.mysql.com/get/mysql57-community-release-el7-11.noarch.rpm
# 安装 mysql 源
yum localinstall mysql57-community-release-el7-11.noarch.rpm
# 用下面的命令检查 mysql 源是否安装成功
yum repolist enabled | grep "mysql.*-community.*"
# 安装 mysql 5.7
yum install -y mysql-community-server
# 启动 mysql 5.7
systemctl start mysqld
# 查看其运行状态
systemctl status mysqld

# 设置开机启动
systemctl enable mysqld
# 重载所有修改过的配置文件
systemctl daemon-reload
```

### Docker-ce 安装
```
# 安装依赖包
yum install -y yum-utils \
device-mapper-persistent-data \
lvm2

yum-config-manager \
--add-repo \
https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

# 使用以下命令来查看可安装版本
yum list docker-ce --showduplicates | sort -r

# 选择其一进行安装 例如 yum install docker-ce-18.06.3.ce
yum install docker-ce-<VERSION STRING>

# 启动Docker
systemctl start docker

# 验证是否安装成功
docker run hello-world
```

### Nginx 在CentOS 7 下安装
---
&emsp;我在这里直接引用别人写的内容，就不多赘述了。
&emsp;[如何安装nginx](https://qizhanming.com/blog/2018/08/06/how-to-install-nginx-on-centos-7)



## 搭建博客篇
&emsp;首先我才用的是Docker 来对博客进行搭建，但是说起来，当时在有官方教程帮助的状况下，依然用了几天才搭建起来，翻阅了很多教程，发现基本没有按照官方的走（大概这样才有价值吧），但是实际上真的很简单，我在这里也向大家推荐使用docker搭建。首先贴出官方教程：[官方教程](https://hacpai.com/article/1492881378588)

```
# 获取最新镜像
docker pull b3log/solo
# 启用solo 博客
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost --server_port=
```
&emsp;大概到这里有些同学就看不懂了，我在这里解释一下，实际上只要到上面去改掉某些数据即可，例如，<font color='red'>JDBC_PASSWORD</font> 需要修改为你自己 Mysql上的root用户下的密码 （当然如果你有新建用户的话也可以对用户做替换），然后其他需要修改的可以直接按官方上面给出的说明来针对自己的情况作修改。

```
--listen_port：进程监听端口
--server_scheme：最终访问协议，如果反代服务启用了 HTTPS 这里也需要改为 https
--server_host：最终访问域名或公网 IP，不要带端口
--server_port：最终访问端口，使用浏览器默认的 80 或者 443 的话值留空即可
```
&emsp;编辑完以后，对编辑后的命令复制粘贴至输入行，回车运行，然后接下来如果需要查看是否成功启动，则可以执行下面命令：
```
docker logs solo
```

&emsp;如果顺利启动，则可以开始配置Nginx 服务器反向代理
```
#输入
cd /etc/nginx/conf.d
#编辑文件
vim reverse.conf 
```
&emsp;然后在键盘上输入`i`(这一步的目的是进入输入模式）
```
upstream backend {
    server localhost:8080; # Solo 监听端口 不用去改
}

server {
    listen       80; # 不需要改
    server_name  88250.b3log.org; # 博客域名 没有域名的话则可以使用ip暂时代替

    access_log off;

    location / {
        proxy_pass http://backend$request_uri;
        proxy_set_header  Host $host:$server_port;
        proxy_set_header  X-Real-IP  $remote_addr;
        client_max_body_size  10m;
    }
}
```

&emsp;之后重新读取nginx 配置文件。
```
nginx -s reload
```
&emsp;就可以尝试输入自己的ip或者域名，会提示初始化成功，就可以登录自己的Github账号开心地玩耍博客啦~

&emsp;当然如果出现nginx 炸出 
```
nginx: [error] open() "/var/run/nginx.pid" failed (2: No such file or directory)
```
&emsp;的问题，可以参考我的[解决办法](http://catswoodpro.xyz/articles/2019/07/14/1563118250578.html)

## 结语
&emsp;这篇分享实际上很早之前就可以写出来，但是中间因为不少事情耽搁了，再加之自己有贼懒，写得也不是很好，很多地方能省就省了哈哈哈哈哈，总之感谢大佬们的付出才有了我偷懒的机会~ 我会一直心怀感激的！