title: (Sunday, May 5, 2019) 阅读记录——HTTP The Definitive Guide
date: '2019-05-05 22:32:43'
updated: '2019-05-10 16:47:29'
tags: [学习笔记]
permalink: /articles/2019/05/05/1557066763477.html
---
&emsp; 由于开始使用康奈尔笔记的方法，笔记记录起来确实是爽，但是后面上传以及排版简直要命....... 总之这玩意没那么好处理，加之上传后图又要被压一遍，就更糊了，所以没有什么参考价值，就算是个读书签到把。 另外再传一份pdf上来把，也算不须今日之汗水了~

[HTTPGUIDEOverviewChapter1.rar](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter1-2dd5157d.rar)

## May 10th 更新

[HTTPGUIDEOverviewChapter2.rar](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter2-344132aa.rar)


