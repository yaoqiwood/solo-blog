title: '[日常遇到問題] 解决 Nginx -s reload時 炸出 /var/run/nginx.pid failed的問題'
date: '2019-07-14 23:30:50'
updated: '2019-07-15 07:41:38'
tags: [待分类]
permalink: /articles/2019/07/14/1563118250578.html
---
###  &emsp;標題帶了繁體字是因爲前面兒想在油管上裝台灣人，一下子想起來還有東西沒寫，又懶得切回來，所以就先用繁體字接著寫吧。

---
&emsp;今天因爲在考慮這個博客的域名問題，因爲測試了下在火狐上是什麽個訪問效果，結果Firefox讓人驚訝，我在輸入[我的博客地址的時候](catswoodpro.xyz)（就是catswoodpro.xyz）發現會自動帶上www，問題是我地址全屏帶www 的話會直接被nginx指向到nginx的默認顯示頁面，所以後來就像修改了下配置文件，把兩個域名都加上去，原來以爲這波反向代理配置完就完事兒了。
尷尬的是在輸入
```
nginx -s reload
```
直接爆出
```
nginx: [error] open() "/var/run/nginx.pid" failed (2: No such file or directory)
```
在這裏我介紹下的云服務器機器的配置是什麽。
系統 Centos 7

![image.png](https://img.hacpai.com/file/2019/07/image-ac6a3af0.png)

查了十幾分鐘谷歌和百度找到了一個可行的辦法

解決辦法
---
```
nginx -c /etc/nginx/nginx.conf
```
然後重新nginx -s reload 發現問題已經解決了，這是爲啥子勒？

問題分析
---
首先我并沒有怎麽學過nginx，大多數配置都是參照網友在網上的分享copy過來的，不過多少還是要閙清楚問題的根源，首先從報錯信息可以得知，
```
nginx: [error] open() "/var/run/nginx.pid" failed (2: No such file or directory)
```
 [error] open() "/var/run/nginx.pid" failed 打開nginx.pid失敗，然後看後半段 No such file or directory 沒有這樣的文件或文件夾，這樣就清楚問題所在了。

那麽分析下
```
nginx -c /etc/nginx/nginx.conf
```
一下内容轉自CSDN上的一位博主的原創内容，[附上鏈接，點擊就看](https://blog.csdn.net/spark_csdn/article/details/80836374)
```
nginx 						#打开 nginx
nginx -t   				        #测试配置文件是否有语法错误
nginx -s reopen					#重启Nginx
nginx -s reload					#重新加载Nginx配置文件，然后以优雅的方式重启Nginx
nginx -s stop  					#强制停止Nginx服务
nginx -s quit  					#停止Nginx服务（即处理完所有请求后再停止服务）


nginx [-?hvVtq] [-s signal] [-c filename] [-p prefix] [-g directives]

-?,-h           : 打开帮助信息
-v              : 显示版本信息并退出
-V              : 显示版本和配置选项信息，然后退出
-t              : 检测配置文件是否有语法错误，然后退出
-q              : 在检测配置文件期间屏蔽非错误信息
-s signal       : 给一个 nginx 主进程发送信号：stop（强制停止）, quit（优雅退出）, reopen（重启）, reload（重新加载配置文件）
-p prefix       : 设置前缀路径（默认是：/usr/share/nginx/）
-c filename     : 设置配置文件（默认是：/etc/nginx/nginx.conf）
-g directives   : 设置配置文件外的全局指令
```
可以看到-c filename是設置配置文件的命令 於是在

![image.png](https://img.hacpai.com/file/2019/07/image-af6b4cb2.png)

指定了pid的路徑，然後重新生成
![image.png](https://img.hacpai.com/file/2019/07/image-9efc4b16.png)

好了，到此總結完畢~

