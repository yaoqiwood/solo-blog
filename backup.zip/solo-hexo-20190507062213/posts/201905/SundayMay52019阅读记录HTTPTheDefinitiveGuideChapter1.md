title: (Sunday, May 5, 2019) 阅读记录——HTTP The Definitive Guide Chapter 1
date: '2019-05-05 22:32:43'
updated: '2019-05-06 08:35:14'
tags: [学习笔记]
permalink: /articles/2019/05/05/1557066763477.html
---
&emsp; 由于开始使用康奈尔笔记的方法，笔记记录起来确实是爽，但是后面上传以及排版简直要命....... 总之这玩意没那么好处理，加之上传后图又要被压一遍，就更糊了，所以没有什么参考价值，就算是个读书签到把。 另外再传一份pdf上来把，也算不须今日之汗水了~

[HTTPGUIDEOverviewChapter1.rar](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter1-2dd5157d.rar)

![HTTPGUIDEOverviewChapter11.png](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter11-d5ab62da.png)
![HTTPGUIDEOverviewChapter12.png](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter12-dbd81c90.png)
![HTTPGUIDEOverviewChapter13.png](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter13-7e1e63ab.png)
![HTTPGUIDEOverviewChapter14.png](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter14-3e64f586.png)
![HTTPGUIDEOverviewChapter15.png](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter15-2907d2f2.png)
![HTTPGUIDEOverviewChapter16.png](https://img.hacpai.com/file/2019/05/HTTPGUIDEOverviewChapter16-ae7ef312.png)


