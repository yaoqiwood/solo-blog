title: '[ bug记录 ] 解决eclipse、idea 使用tomcat 启动项目时读取不到配置文件的问题'
date: '2019-07-17 07:57:05'
updated: '2019-07-17 07:57:05'
tags: [Bugs, 随笔]
permalink: /articles/2019/07/17/1563321424789.html
---
首先每个人的电脑环境上都有差异，根据自己个人的情况去做分辨
----

## eclipse
如果出现没有读取到properties的情况，首先可以尝试对项目右击properties （eclipse下 快捷键alt + enter）
![image.png](https://img.hacpai.com/file/2019/07/image-f0a494fa.png)


注意查看Java Build Path 下的的include 和exclude是否正确
![image.png](https://img.hacpai.com/file/2019/07/image-5f4c57dc.png)

其次，到tomcat的webapps底下查看classs文件夹是否有正确加载配置文件。

![image.png](https://img.hacpai.com/file/2019/07/image-61435b46.png)

如没有则需要在properties下 找到web Deployment Assembly 查看resources 是否有正确加载
![image.png](https://img.hacpai.com/file/2019/07/image-e0b39669.png)

如果以上都没问题，那就需要确认一点，是否有在IDE 工具上安装JRebel 插件，如果有的话，恭喜，尝试在项目右击下

![image.png](https://img.hacpai.com/file/2019/07/image-bd02ee57.png)

尝试disable 然后再在tomcat设置里 把
![image.png](https://img.hacpai.com/file/2019/07/image-3329fe69.png)
Enable JRebel Agent 关掉，之后就能正常启动项目啦（当然如果还没有成功启动则可能是其他问题）

## Idea

Idea部分相对简单些，直接对项目查看标注，是否正确表示为resources
![image.png](https://img.hacpai.com/file/2019/07/image-a9e2f455.png)

如果还是无法正常启动，则一样去JRebel那里取消勾选项目即可


## 结语
之前因为这个问题在公司莫名其妙卡了两个小时，之后怀疑到JRebel上，尝试了下才发现真的是因为这个问题才导致的，很多人也许会问，关闭JRebel以后热部署不就不能实现了么？ 实际上只有再把之前JRebel中 Project选项卡里的 要进行热部署的项目重新勾选起来，让其重新再打包加载，问题就能得到解决了。
