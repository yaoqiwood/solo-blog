title: '[日常记录] 关于廖雪峰大大Python 教程的高阶函数 map/reduce 的课后习题自己的题解'
date: '2019-10-20 22:35:09'
updated: '2019-11-14 10:52:43'
tags: [学习, Python学习, 日常問題]
permalink: /articles/2019/10/20/1571582108928.html
---
# 练习
## 题目一：

利用`map()`函数，把用户输入的不规范的英文名字，变为首字母大写，其他小写的规范名字。输入：`['adam', 'LISA', 'barT']`，输出：`['Adam', 'Lisa', 'Bart']`：

```
def normalize(name):
    temp = name[0].upper()
    i = 1
    while i < len(name):
        temp += name[i]
        i += 1
    return temp
  
# 测试: 
L1 = ['adam', 'LISA', 'barT'] 
L2 = list(map(normalize, L1)) 
print(L2)
```
### 当然实际上这个是自己写的方法，写法土味但能实现，所以实际上完全可以用另一种简单的方法实现

```
# 尝试简化 lambda
L3 = list(map(lambda name: name.capitalize(), L1))
print(L3)
```

## 第二题
Python提供的`sum()`函数可以接受一个list并求和，请编写一个`prod()`函数，可以接受一个list并利用`reduce()`求积：
```
def prod(L):
    def mul(x, y):
        return x * y

    return reduce(mul, L)

## 测试
print('3 * 5 * 7 * 9 =', prod([3, 5, 7, 9]))

if prod([3, 5, 7, 9]) == 945:
    print('测试成功!')
else:
    print('测试失败!')
```

### 一样可以尝试简化：
```
def prod(L):
    return reduce(lambda x, y: x * y, L)
```


## 第三题：
利用`map`和`reduce`编写一个`str2float`函数，把字符串`'123.456'`转换成浮点数`123.456`：

讲道理，这道题着实让我想了一段时间，最后还是靠评论区的大佬辅导并且稍作改动后有了其他有些不一样的写法：


```
DIGITS = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9}


def str2float(s):
    L = s.split(".")

    def char2int(str):
        return DIGITS[str]

    int_num = reduce(lambda x, y: x * 10 + y, map(char2num, L[0]))
    float_num = reduce(lambda x, y: x * 10 + y, map(char2num, L[1]))
    return int_num + float_num / 10 ** len(L[1])

# 注意上面的10 ** len(L[1])，这里之所以这么写的原因，主要考虑到函数的复用性问题，早期
#评论区的有位老哥，他是把这里写死为 1000 ，虽然这样可以过掉测试代码的结果，但是没办法
#被复用，所以如此，使用位数来作指数函数运算，最终得出的会是一个正确的数字

# 测试代码
print('str2float(\'123.456\') =', str2float('123.456'))
if abs(str2float('123.456') - 123.456) < 0.00001:
    print('测试成功!')
else:
    print('测试失败!')
```
