title: '[ 经验分享 ] 如何让Eclipse 能够像Idea 那样对Jar包反编译查看代码'
date: '2019-08-02 19:48:06'
updated: '2019-08-02 19:52:46'
tags: [随笔, 记录分享, 经验分享]
permalink: /articles/2019/08/02/1564746486671.html
---
# 晚上加班事情不太多 瞎基尔写点内容上来水

&emsp;安装一个插件即可,点击Help
![image.png](https://img.hacpai.com/file/2019/08/image-06826546.png)

&emsp;打开Eclipse Marketplace ，


![image.png](https://img.hacpai.com/file/2019/08/image-3192c2f0.png)

&emsp;找到Enhanced Class Decompiler 点击Install

&emsp;之后就是一点点去安装操作即可。

&emsp;安装完成后，找到eclipse上方的

![image.png](https://img.hacpai.com/file/2019/08/image-4a8e4f58.png)

Preferences 找到 ![image.png](https://img.hacpai.com/file/2019/08/image-bd229cd0.png)

File Association （为了快速找到可以在搜索栏中输入，`file ass` 

&emsp;点击
![image.png](https://img.hacpai.com/file/2019/08/image-d5f62ca5.png)

![image.png](https://img.hacpai.com/file/2019/08/image-225316e2.png)
然后将下方的 Class Decompiler Viewer 修改为Default 即可。

然后就可以愉快地玩耍啦~


