title: 影片简评——我們與惡的距離 The World Between Us
date: '2019-05-04 21:38:08'
updated: '2019-05-04 21:38:08'
tags: [影片]
permalink: /articles/2019/05/04/1556977087923.html
---
## &emsp;我們與惡的距離
&emsp;前段時間在看台灣政論節目中，唐湘龍都提到這部電視劇，今天假期最後一天也是百無聊賴，窮極無聊還是選擇去看劇了，結果發現意外地好看，不管是深度還是剪輯的手法上看，都是上乘作品，總之很棒~推薦喜歡看社會類型日劇的朋友也來看看這部台劇。
![image.png](https://img.hacpai.com/file/2019/05/image-c96ab3a3.png)
