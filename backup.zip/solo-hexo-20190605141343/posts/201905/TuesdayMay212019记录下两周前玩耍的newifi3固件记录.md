title: (Tuesday, May 21, 2019) 记录下两周前玩耍的newifi3 固件记录
date: '2019-05-21 13:14:22'
updated: '2019-05-22 21:58:56'
tags: [随笔]
permalink: /articles/2019/05/21/1558415662225.html
---
![image.png](https://img.hacpai.com/file/2019/05/image-167d7a24.png)


就这么个东西，主要便宜 X宝上150就能买个全新的，60多块钱也能收个成色不错的，总之性价比极高，可玩性也强，配置不错，也有512MB的内存，各方面都挺好。

首先刚拿来我就刷了个Breed （刷不死固件）  具体步骤是酱紫的：

首先下载：
链接: https://pan.baidu.com/s/12iKHNLEtfsPCsJB8oarUng 提取码: q241 
# Breed

&emsp; 其实关于这个内容网上教程挺多的，不过就当是个记录，首先查询下网关，或者叫路由器后台管理界面，newifi3的出厂设置都是192.168.99.1 这个就不需要详细赘述了，进入即可~好了 接下来是关键：
&emsp; 1. 打开SSH 在浏览器中输入 http://192.168.99.1/newifi/ifiwen_hss.html 并进入 此时浏览器会出现页面会显示 SUCCESS，即代表成功。
&emsp; 2. 使用putty进入路由器命令行界面，这个实际上也不复杂，当然对Linux系统熟悉的同学就更不是问题了。（这里未必一定要使用putty SecureCRT 这样的终端工具应该也是没问题的）

![Annotation20190512164439.png](https://img.hacpai.com/file/2019/05/Annotation20190512164439-d1adc2e9.png)

&emsp;  login as 这边用的是root 密码就是路由器后台设定的密码，进入后，打开WinScp 将文件上传至tmp 文件夹（由于路由器不在手边没办法直接演示） 这里可能有同学会问，能不能SecureFXP 等这类工具来进行上传呢？ 答案是，不能，至少SecufreFXP 是没办法的，我自己就是尝试使用SecureFXP 来上传，但是永远会卡死在0%，之后尝试使用WinScp 就成功了。

将newifi-d2-jail-break.ko 上传至tmp文件夹即可

![image.png](https://img.hacpai.com/file/2019/05/image-20861d22.png)

之后呢 在终端通过命令行进入刚刚上传的那个路径，也就是tmp，然后输入命令
`insmod newifi-d2-jail-break.ko`
稍等片刻终端将会失去响应，不用慌，这是正常现象，（因为 newifi-d2-jail-break.ko 会冻结系统的其他功能，强制写入 Newifi D2 专用版 Breed 到 Flash）
成功后路由器会自动重启。断电后按复位健/USB键然后通电开机均可进入 Breed（一定要按住复位键然后再通电才行的）

重新开机后输入192.168.1.1 进入breed界面。

到此先告一段落，因为实际上能到breed 也就等于能刷不同的固件了，可玩性极高，剩下的自行探索就好~

