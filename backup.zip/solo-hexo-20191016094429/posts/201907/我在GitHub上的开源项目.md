title: 我在 GitHub 上的开源项目
date: '2019-07-13 10:55:19'
updated: '2019-07-13 10:55:19'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/yaoqiwood/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://catswoodpro.xyz`](http://catswoodpro.xyz "项目主页")</span>

yaoqiwood 的个人博客 - 记录精彩的程序人生



---

### 2. [Catwood_blog](https://github.com/yaoqiwood/Catwood_blog) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/Catwood_blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/Catwood_blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/Catwood_blog/network/members "分叉数")</span>

日常练习用（博客系统源码  日常提交一些） 目前后端仅提交后端代码  使用spring+springMVC+Mybatis+maven 等.....



---

### 3. [parkingCarSystem](https://github.com/yaoqiwood/parkingCarSystem) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/parkingCarSystem/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/parkingCarSystem/stargazers "收藏数")&nbsp;&nbsp;[🖖`3`](https://github.com/yaoqiwood/parkingCarSystem/network/members "分叉数")</span>

某停车收费管理系统（作为代码仓库标记所用



---

### 4. [CocosCreatorGameDemo](https://github.com/yaoqiwood/CocosCreatorGameDemo) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/CocosCreatorGameDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/CocosCreatorGameDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/CocosCreatorGameDemo/network/members "分叉数")</span>

以前毕设时写的小游戏，内容不多，作为游戏编程的入门



---

### 5. [PackagedCardForHospital](https://github.com/yaoqiwood/PackagedCardForHospital) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/PackagedCardForHospital/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/PackagedCardForHospital/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/PackagedCardForHospital/network/members "分叉数")</span>

练习JavaEE Servlet 用 使用前端JQ+AJAX 后端 Tomcat8.5+Oracle 11g



---

### 6. [KTV_Project_Test](https://github.com/yaoqiwood/KTV_Project_Test) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/KTV_Project_Test/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/KTV_Project_Test/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/KTV_Project_Test/network/members "分叉数")</span>





---

### 7. [TankBattles](https://github.com/yaoqiwood/TankBattles) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/TankBattles/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/TankBattles/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/TankBattles/network/members "分叉数")</span>

Test



---

### 8. [PingPong_1](https://github.com/yaoqiwood/PingPong_1) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/PingPong_1/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/PingPong_1/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/PingPong_1/network/members "分叉数")</span>





---

### 9. [PingPong_1new](https://github.com/yaoqiwood/PingPong_1new) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yaoqiwood/PingPong_1new/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/yaoqiwood/PingPong_1new/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yaoqiwood/PingPong_1new/network/members "分叉数")</span>



