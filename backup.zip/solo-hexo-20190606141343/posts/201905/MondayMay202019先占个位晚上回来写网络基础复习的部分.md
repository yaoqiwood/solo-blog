title: (Monday, May 20, 2019) 先占个位，晚上回来写网络基础复习的部分
date: '2019-05-20 17:59:33'
updated: '2019-06-03 10:58:13'
tags: [学习笔记]
permalink: /articles/2019/05/20/1558346373534.html
---
## 计算机网络层次划分

#### OSI模型
&emsp;**什么是OSI模型？**
&emsp;**开放式系统互联通信参考模型**（英语：Open System Interconnection Reference Model，缩写为 OSI），简称为OSI模型（OSI model），**一种概念模型**，由国际标准化组织提出。
&emsp;一个**试图**使各种计算机在世界范围内**互连为网络的标准框架**。定义于ISO/IEC 7498-1。   
![image.png](https://img.hacpai.com/file/2019/06/image-455e77a6.png)

&emsp;在整个网络环境中 A主机发送数据包至B主机，可以用下图简单了解发送接收的过程：
![Image.png](https://img.hacpai.com/file/2019/06/Image-d0e14c46.png)


七层划分 自下而上介绍可以为：

### 第一层 物理层
&emsp;物理层规定:为传输数据所需要的物理链路创建、维持、拆除，而提供具有机械的，电子的，功能的和规范的特性。简单的说，物理层确保原始的数据可在各种物理媒体上传输。局域网与广域网皆属第1、2层。
**比特流传输**

&emsp;简单的说（说人话）：就是物理层负责最后将信息编码成电流脉冲或其它信号用于网上传输，实际的例子，也就是RJ45接口将电讯号转换为0和1

&emsp;关于RJ45插头，在日常在网络硬件中极为常见，
![Image2.png](https://img.hacpai.com/file/2019/06/Image2-562ce54d.png)
![Image3.png](https://img.hacpai.com/file/2019/06/Image3-08461dc6.png)

&emsp;图上有提到 8P8C，那么什么又是8P8C插头呢？



&emsp;实际上就是RJ45，8P8C（8 position 8 contact）的意思是8个位置（Position，指8个凹槽）、8个触点（Contact，指8个金属接点）。
&emsp;总之是以太网使用双绞线连接时常用的一种连接器插头。
### 第二层 数据链路层
&emsp;数据链路层（Data Link Layer）负责**网络寻址**、**错误侦测和改错**。当表头和表尾被加至数据包时，**会形成帧（frame）**。数据链表头（DLH）是包含了物理地址和错误侦测及改错的方法。数据链表尾（DLT）是一串指示数据包末端的字符串。例如以太网、无线局域网（Wi-Fi）和通用分组无线服务（GPRS）等。
>分为两个子层：逻辑链路控制（logical link control，LLC）子层和介质访问控制（media access control，MAC）子层。

&emsp;简单的说（说人话）：规定了0和1的分包形式，确定了网络数据包的形式；

![Image4.png](https://img.hacpai.com/file/2019/06/Image4-b91400f7.png)

### 第三层 网络层
&emsp;网络层（Network Layer）决定数据的路径选择和转寄，将网络表头（NH）加至数据包，以形成分组。网络表头包含了网络数据。例如:互联网协议（IP）等。
&emsp;到网络层，包解析后大致是如下图情况：

![Image5.png](https://img.hacpai.com/file/2019/06/Image5-c3a6bd52.png)

&emsp;如上图，FCS作为数据链路层中MAC子层，用于检测比特错误，所以被称作帧检验序列FCS，**发送数据前**先计算帧的数据部分得出**FCS添加在数据部分后**，接收端收到数据后添加上FCS后计算验证。


&emsp;那么讲到网络层，网络层的作用简单理解即是负责在源和终点之间建立连接，也可用于确定位置，如何确定？这里就是要讲起IPV4和IPV6，

##### IPV4
&emsp;中文名称为：网际协议版本4&emsp; 英文则称作：Internet Protocol version 4

&emsp;关于IPV4与IPV6的环境现状：
>网际协议开发过程中的第四个修订版本，也是此协议第一个被广泛部署和使用的版本。其后继版本为IPv6，直到2011年，IANA IPv4位址完全用尽时，IPv6仍处在部署的初期。

IPv4是一种**无连接的协议**，操作在使用分组交换的链路层（如以太网）上。

如果我们使用WireShark进行抓包，则会看到

![Image6.png](https://img.hacpai.com/file/2019/06/Image6-1ebaa09d.png)

#### IPV6

![1200pxIpv6addressleadingzeros.svg.png](https://img.hacpai.com/file/2019/06/1200pxIpv6addressleadingzeros.svg-d9a222bd.png)

关于TCP 
https://www.jianshu.com/p/ff36b6ab503e

关于UDP
### 第四层 传输层

&emsp;传输层（Transport Layer）把传输表头（TH）加至数据以形成数据包。传输表头包含了所使用的协议等发送信息。例如:传输控制协议（TCP）等。

&emsp;传输层向高层提供可靠的端到端的网络数据流服务。对应的网络协议有TCP/UDP (Transmission  Control Protocal/User Datagram  Protocol )

实际应用例如网关

![Image7.png](https://img.hacpai.com/file/2019/06/Image7-feefb313.png)
关于TCP 直接看数据包或许更加直观
![Image8.png](https://img.hacpai.com/file/2019/06/Image8-101cc424.png)

看到CSDN 有人这么比喻：

>假如 IP 是网络世界的门牌，那么这个端口就是那个门牌号码上建筑物的楼层！  每个建筑物都有 1~65535 层楼，你需要什么网络服务，就得要去该对应的楼层取得正确的资料。但那个楼层里面有没有人在服务你呢？ 这就得要看有没有程序真的在执行啦。所以，IP 是门牌， TCP 是楼层，真正提供服务的， 是在该楼层的那个人 (程序)！

### 第五层 会话层


&emsp;会话层（Session Layer）负责在数据传输中设置和维护计算机网络中两台计算机之间的通信连接。

&emsp;负责建立连接和断开通信连接作用，可以理解成快递公司的快递员。
![Image9.png](https://img.hacpai.com/file/2019/06/Image9-27213fc6.png)

&emsp;但是由于TCP/IP 机制，这一层和表示层被并入应用层中去。

### 第六层 表示层

&emsp;但是由于TCP/IP 机制，这一层和表示层被并入应用层中去。

&emsp;表示层(Presentation Layer)把数据转换为能与接收者的系统格式兼容并适合传输的格式。

&emsp;接收不同的形式的信息，如文字流，图像，声音等。例如浏览器请求而得到的数据，将解析成什么数据，是因表示层转换。

 ### 第七层 应用层
 
&emsp;TCP/IP中，作为5层模型的最后一层，作为OSI模型的最后一层，它提供各种协议，如很多人所熟知的协议，如HTTP,HTTPS,FTP 等等。

### 关于IP的一些延申
&emsp;在配置IP地址，时长能看到子网掩码和IP地址，如下图：
![Image10.png](https://img.hacpai.com/file/2019/06/Image10-d5903a32.png)

&emsp;说到这里首先需要结合IP地址运算（十进制转二进制），同时将子网掩码转换成二进制码，并作与运算，便可以得到主机号和网络号。

### 广播地址
&emsp;可以理解成向某个网络群体发送消息，假设一个IP地址 10.1.1.0 子网掩码为 255.255.255.0 ，那么其广播地址就是 00001010.00000001.00000001.11111111（二进制），也就是10.1.1.255 

### 地址分类
&emsp;A类地址：0 为开头
&emsp;B类地址：10 为开头
&emsp;C类地址：110 为开头
&emsp;D类地址：1110 为开头
&emsp;E类地址：1111为开头

### 环回口
&emsp;127.0.0.1 （255.0.0.0）


### 私有地址
&emsp;经常查看路由器大概会知道私有地址转换协议什么的（NAT) ，地址池一般会配置在192.168.0.1 ~ 192.168.254.254

&emsp;同样的概念 A类私有地址为：10.0.0.0
&emsp;B类：172.16.0.0
&emsp;C类： 192.168.0.0

### 路由选择协议

&emsp;RIP 协议 最大跳数为15跳
&emsp;那么什么是“跳”呢？
&emsp;首先英文称作 （Hop Count），然后每经过一个三层设备跳数增加1，这里的三层设备可以参考OSI模型，就是网络层设备，RIP 通过UDP协议 进行路由表报文信息的交换，所以并不可靠。

实际例子
![Image11.png](https://img.hacpai.com/file/2019/06/Image11-e0f9cd7b.png)

![Image12.png](https://img.hacpai.com/file/2019/06/Image12-c74808be.png)

&emsp;R2路由表
![Image13.png](https://img.hacpai.com/file/2019/06/Image13-b5268d9e.png)

 R1收到R2的路由表更新信息
![1.png](https://img.hacpai.com/file/2019/06/1-3ff483be.png)

![2png.png](https://img.hacpai.com/file/2019/06/2png-d40dc8e4.png)

以上参考：https://www.jianshu.com/p/f542d5b415a1




