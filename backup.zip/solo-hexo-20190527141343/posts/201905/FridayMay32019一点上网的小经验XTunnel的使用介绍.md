title: (Friday, May 3, 2019) 一点上网的小经验—— X-Tunnel 的使用介绍
date: '2019-05-03 07:34:46'
updated: '2019-05-03 08:00:59'
tags: [上网姿势和han技巧]
permalink: /articles/2019/05/03/1556840086524.html
---
# 其实就是一些顶风作X的内容，面向同学和朋友，有些许参考价值但不多，大佬看勒笑笑就好😂
&emsp;之前有朋友一直在问我，最近都看不了台湾新闻了，好痛苦啊~~~ 这样的，但是我也一直苦于没有很好的交流平台去告诉他们有什么工具是好用的能用的（墙内太容易就被河蟹了），刚好某天逛论坛有朋友在分享自己在用的工具，我看勒之后感觉好不错，也尝试拿出来使用，事实证明确实很好，首先呢，它长这样。

![Annotation20190503071619.png](https://img.hacpai.com/file/2019/05/Annotation20190503071619-fa7bf0c4.png)

<font color=#FF0000>它是收费的！它是收费的！它是收费的! 重要的事情说三遍！😂</font>

当然它有提供500M的免费使用带宽。我个人有测试了下，看油管啥子的速度很棒，1080P也能跑。
那么往下开始教程，如何使用XX-Net 来实现高速看油管。

---

首先感谢 论坛内的朋友的分享。
https://github.com/XX-net/XX-Net/blob/master/code/default/download.md

首先到github的这个地址去下载稳定版
![image.png](https://img.hacpai.com/file/2019/05/image-e254ae1b.png)
下载完成，解压，并打开
![image.png](https://img.hacpai.com/file/2019/05/image-3eaace8f.png)
start.bat 之后就是各种命令行跑以及生成证书，是中文就按“是”，英文一样点击“Yes” 就好
之后便会在桌面生成

![image.png](https://img.hacpai.com/file/2019/05/image-efdc7156.png)

需要注意的是第一次使用是要注册账号的，这个相信大家打开后看到"Register"这个按钮就知道是做什么的了（英文实在不好的就自己去搞一个翻译软件）
![image.png](https://img.hacpai.com/file/2019/05/image-d0a72b39.png)
登录后会显示剩余的流量，然后在任务栏上的x-net的图标上右击选择模式
![image.png](https://img.hacpai.com/file/2019/05/image-98a47abc.png)

接下来一步比较关键，到浏览器的高级设置上，去设置局域网代理，以Chrome为例，Setting ->  Advanced -> Open proxy settings -> Lan settings
![image.png](https://img.hacpai.com/file/2019/05/image-4a6968e4.png)

![image.png](https://img.hacpai.com/file/2019/05/image-92b43f96.png)

![image.png](https://img.hacpai.com/file/2019/05/image-56baa345.png)

需要注意的是，上面的端口必须以官方的WIKI 为标准，修改为1080 点击OK，就可以尝试进入Google访问啦~
![image.png](https://img.hacpai.com/file/2019/05/image-8fe918a3.png)

让我们来测试一下速度。
![image.png](https://img.hacpai.com/file/2019/05/image-9bd387b1.png)

速度也是很快的，然后其余的类似购买的套餐内容我看了下，貌似是300G 3个月然后5.6$这个样子 换算￥好像也不贵的样子，基本也算是够用了。另外它好像只支持Paypal 这个样子，但好在Paypal 已经在中国大陆有开展业务，且支持银联，算是和支付宝可以一样去用的。

---

结语：本身这个X-Tunnel 的内容都很简单，就是些基本的操作，有什么疑问可以上官方Wiki 上查看，基本都有涉及到如何去使用。 分享就到这边~😂








