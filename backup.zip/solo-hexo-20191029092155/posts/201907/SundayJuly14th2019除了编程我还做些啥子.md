title: ( Sunday, July 14th, 2019 ) 除了编程我还做些啥子。。。
date: '2019-07-14 17:28:01'
updated: '2019-07-14 17:46:39'
tags: [随笔]
permalink: /articles/2019/07/14/1563096481647.html
---
### 说在前头，此片存粹是为了发牢骚用的
其实也就是想写点最近工作以外还玩了些什么游戏或者内容（学习除外，因为除了学习其他都做了）

游戏
---
&emsp;不得不说“杀戮尖塔” 这屌游戏太他妈 魔性了，原来准备吃完饭下午睡个觉啥子的，睡之前想打把牌，结果进了游戏就打了两把发现运气不错，抓到了几张刀贼的关键牌，然后。。。就没然后了，一直打到通关，也就差不多2，3个小时过去了。。。我日，然后周末是过得挺不爽的，囊中羞涩，想要积蓄却被可怕的物价给绑架，太他妈真实了把~

<center><img src="https://img.hacpai.com/file/2019/07/image-aa60f7cb.png"/></center>

&emsp;
&emsp;话题远了，上面就是我最近累计游戏时长，以后还是注意些把，在这么打下去，想要的没捞着，不想要的全会找上门儿~~~~

&emsp;在这里立个flag，这周不打游戏且看完这本书！![image.png](https://img.hacpai.com/file/2019/07/image-4d4aa183.png)

&emsp;

服务器
---
有的时候是真滴让人不省心，也不清楚是不是centos7 的问题，老是出幺蛾子，找个时间把这些问题单独列出来

音乐
---
&emsp;说起来其实也是挺好的，我所在的公司允许写代码的时候戴耳机听些音乐，所以我也罗列一些平常我在写代码，工作，学习之余会听的些音乐（纯音乐，pop、jazz以后另放歌单）

### 由于考虑到很多同学并不知道如何科学上网（我也不会主动教的），这里就发一些墙内的搬运音乐吧。
### &emsp;1. [10 hour lofi hip hop radio - smooth beats to study_sleep_relax](https://www.bilibili.com/video/av42911554?from=search&seid=559864943636792623)

![image.png](https://img.hacpai.com/file/2019/07/image-c4645c6a.png)

### <center/> TO BE CONTINUED ....
