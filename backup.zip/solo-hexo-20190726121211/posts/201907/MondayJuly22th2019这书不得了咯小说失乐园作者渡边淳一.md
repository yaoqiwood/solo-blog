title: (Monday, July 22th, 2019 ) 这书不得了咯—— 小说《失乐园》 作者：渡边淳一
date: '2019-07-22 06:58:06'
updated: '2019-07-23 06:19:46'
tags: [读书笔记, 随笔]
permalink: /articles/2019/07/22/1563749886284.html
---
<center>写在开头：用于分享读书笔记用</center>
---
&emsp;我有个习惯，凡是这种 译序 都会去尝试看完，因为确实是一种快速了解将要读的书籍是怎样的轮廓。 此篇也是如此，但是惊讶的是，大概这书的开头就这么开门见山地告诉你“我很不正经”。
<img algin="center" src="https://img.hacpai.com/file/2019/07/screenshot20190722T0648120800-3b1490d4.png">
<img align="center" src="https://img.hacpai.com/file/2019/07/screenshot20190722T0648180800-5af36999.png">

