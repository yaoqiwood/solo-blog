title: (Friday, May 3, 2019 ) 往后的计划发布
date: '2019-05-03 09:36:25'
updated: '2019-05-04 08:48:17'
tags: [计划]
permalink: /articles/2019/05/03/1556847385490.html
---
* [ ]  圣经 NIV （实际上去年就有在读英文版的，现在的进度是Leviticus 16:4 版本是NIV)
![image.png](https://img.hacpai.com/file/2019/05/image-b1d5ee6f.png)

* [ ]  May 4th 计划当前阅读
![image.png](https://img.hacpai.com/file/2019/05/image-6dc56edc.png)

