title: '(Wednesday, May 1st, 2019 ) 关于这个未来的计划 '
date: '2019-05-01 22:54:25'
updated: '2019-05-04 15:03:28'
tags: [计划]
permalink: /articles/2019/05/01/1556722465740.html
---
![70575047p0master1200.jpg](https://img.hacpai.com/file/2019/05/70575047p0master1200-7514c089.jpg)

> > ###     有空就瞎几把捉摸点其他新的好玩的东西上来
* [ ]  HTTPS

      Thursday May 4, 2019
&ensp;&ensp;&ensp; 有想要去更换一个域名服务商（新加坡的那种，这样就不用备案那么麻烦了）,打脸，最终还是无法在继续备案和另买海外域名中权衡，所以继续纠结把......

      Thursday May 2, 2019 
&ensp;&ensp;&ensp;<font face=微软雅黑> 作了一系列尝试后，发现HTTPS不止是要在Tomcat 上修改一系列配置以外，还要对在域名服务商那里生成证书，所以在这里的话，本身域名因为各种（懒），导致到现在还没有去备案，所以就目前而言，HTTPS 改造计划暂缓。</font> 
    

